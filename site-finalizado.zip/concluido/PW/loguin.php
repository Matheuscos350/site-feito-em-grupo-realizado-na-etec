<?php

include('cabecalho.php');

include('menu.php');

?>


 <!-- Bootstrap CSS -->
 <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-+0n0xVW2eSR5OomGNYDnhzAbDsOXxcvSN1TPprVMTNDbiYZCxYbOOl7+AMvyTG2x" crossorigin="anonymous">
<!-- CSS only -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">


<link rel="stylesheet" href="css/new 1.css">
<link rel="stylesheet" href="css3/css.css">




    <script src="./js/main.js" type='module' defer></script>






    <div class="alert alert-dark" role="alert">
<center><h1>Login </h1></center>
</div>


</head>
<body>




    <CENTER>
    <form action="pessoa-inserir.php" method="post">
        <main class="container">
            

            <div>
			<input for="exampleInputEmail1" type="hidden" placeholder="idPessoa" name="txIdPessoa" value="<?php echo @$_GET['idPessoa']; ?>" />
		    </div>

            <div class="row">
            <label for="nome">Nome</label>
                <div class="inputbox">
                    <input type="text" name="txNome" id="nome" required>
                    
                </div>

                
                </div>
            </div>
            <div class="row">
            <label for="cep">CEP</label>
                <div class="inputbox">
                    <input type="text" name="txCep" id="cep"  required>
                
                </div>
                <label for="endereco">Endereço</label>
                <div class="inputbox">
                    <input type="text" name="txEndereco" id="endereco"  required>
                
                </div>
                <label for="numero">Número</label>
                <div class="inputbox">
                    <input type="text" name="txNumero" id="numero"  required>
                
                </div>
            </div>
            <div class="row">
            <label for="bairro">Bairro</label>
                <div class="inputbox">
                    <input type="text" name="txBairro" id="bairro"  required>
                
                </div>
                <label for="cidade">Cidade</label>
                <div class="inputbox">
                    <input type="text" name="txCidade" id="cidade"  required>
            
                </div>
                <label for="estado">Estado</label>
                <div class="inputbox">
                    <input type="text" name="txEstado" id="estado"  required>
                
                </div>
            </div>
            <BR>
            <BR>
            <div class="row">
                <input class="btn btn-outline-success" type="submit" value="Salvar" />
                
            </div>
        </main>
    </form>
    </CENTER>
    
    <footer>
       






    </footer>
</body>
</html>



<!-- Optional JavaScript; choose one of the two! -->

 <!-- Option 1: Bootstrap Bundle with Popper -->
 <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-gtEjrD/SeCtmISkJkNUaaKMoLD0//ElJ19smozuHV6z3Iehds+3Ulb9Bn9Plx0x4" crossorigin="anonymous"></script>

<!-- Option 2: Separate Popper and Bootstrap JS -->
<!--
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js" integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.min.js" integrity="sha384-Atwg2Pkwv9vp0ygtn1JAojH0nYbwNJLPhwyoVbhoPwBhjQPR5VtM2+xf0Uwh9KtT" crossorigin="anonymous"></script>
-->




<!-- Font Awesome -->
<link
 href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css"
 rel="stylesheet"
/>
<!-- Google Fonts -->
<link
 href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700&display=swap"
 rel="stylesheet"
/>
<!-- MDB -->








<?php

include('rodape.php');
?>