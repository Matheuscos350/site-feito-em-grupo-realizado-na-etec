<?php

include('cabecalho.php');

include('menu.php');

?>


 <!-- Bootstrap CSS -->
 <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-+0n0xVW2eSR5OomGNYDnhzAbDsOXxcvSN1TPprVMTNDbiYZCxYbOOl7+AMvyTG2x" crossorigin="anonymous">

<link rel="stylesheet" href="css/new 1.css">





</div>
</div>
</nav>
<br>

<br>
<div class ="container">
<!--inicio carrosel-->
<div id="carouselExampleControls" class="carousel slide" data-bs-ride="carousel">
  <div class="carousel-inner">
    <div class="carousel-item active">
      <img id="img2" src="img2/2.png" class="d-block w-100" alt="...">
    </div>
    <div class="carousel-item">
      <img id="img2" src="img2/3.png" class="d-block w-100" alt="...">
    </div>
    <div class="carousel-item">
      <img id="img2" src="img2/1.png" class="d-block w-100" alt="...">
    </div>
    <!-- <div class="carousel-item">
    <iframe width="1500" height="900" src="https://www.youtube.com/embed/8pzhWJTfbKQ" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
    </div> -->
  </div>

  
  
  <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleControls" data-bs-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Previous</span>
  </button>
  <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleControls" data-bs-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Next</span>
  </button>

  
</div>
<br>
<center>
<form method="post" action="cookie.php" >
        <label>Selecione uma categoria:</label> 
        <select id="txtCategoria" name="txtCategoria">
           
            <option value="1"> Camisas</option><!--Thumnb -->
            <option value="2">Chuteira</option><!-- Banner-->
            <option value="3">Meião</option> <!-- Flyer -->
            <option value="4">Jaquetas/Corta-Vento</option>
        </select>
        <input type="submit" value="Enviar">
    </form>
</center>
<br>
<br>

<?php
include('recebimento.php');
   if(isset($_COOKIE['categoriaInst']))
     if($_COOKIE['categoriaInst'] == 1){
      echo("
                    <div class='container'>
                    <div class='row row-cols-8 row-cols-lg-4 g-2 g-lg-3'>
                ");
                foreach($THUMB as $produto_indice => $value){
                    echo("<div class='col'>
                            <div class='card' style='width: 300px;'>
                                <img src=".$value[0]."  class='card-img-top' alt=''>
                                <div class='card-body'>
                                    <h5 class='card-title'>".$value[1]."</h5>
                                    <h5 class='card-title'>".$value[2]."</h5>
                                    <a href='#' class='btn btn-primary'>Comprar</a>
                                </div>
                            </div>
                         </div>
                    ");
                }
                echo("</div>
                </div>

                <br>");

                echo("
                    <div class='container'>
                    <div class='row row-cols-8 row-cols-lg-4 g-2 g-lg-3'>
                ");
                foreach($BANNER as $produto_indice => $value){
                  echo("<div class='col'>
                  <div class='card' style='width: 300px; height:300px;'>
                      <img src=".$value[0]." class='card-img-top' alt=''>
                      <div class='card-body'>
                          <h5 class='card-title'>".$value[1]."</h5>
                          <h5 class='card-title'>".$value[2]."</h5>
                          <a href='#' class='btn btn-primary'>Comprar</a>
                      </div>
                  </div>
               </div>
          ");
      }
      echo("</div>
      </div>
      <br>");
      echo("
      <div class='container'>
      <div class='row row-cols-8 row-cols-lg-4 g-2 g-lg-3'>
  ");
                foreach($FLYER as $produto_indice => $value){
                  echo("<div class='col'>
                  <div class='card' style='width: 300px;height:300px;'>
                      <img src=".$value[0]." class='card-img-top' alt=''>
                      <div class='card-body'>
                          <h5 class='card-title'>".$value[1]."</h5>
                          <h5 class='card-title'>".$value[2]."</h5>
                          <a href='#' class='btn btn-primary'>Comprar</a>
                      </div>
                  </div>
               </div>
          ");
      }
      echo("</div>
      </div>
      <br>");
      echo("
      <div class='container'>
      <div class='row row-cols-8 row-cols-lg-4 g-2 g-lg-3'>
  ");
                foreach($FANART as $produto_indice => $value){
                  echo("<div class='col'>
                  <div class='card' style='width: 300px;'>
                      <img src=".$value[0]." class='card-img-top' alt=''>
                      <div class='card-body'>
                          <h5 class='card-title'>".$value[1]."</h5>
                          <h5 class='card-title'>".$value[2]."</h5>
                          <a href='#' class='btn btn-primary'>Comprar</a>
                      </div>
                  </div>
               </div>
          ");
      }
      echo("</div>
      </div>
      <br>");
                
  }
  elseif(isset($_COOKIE['categoriaInst']))
  if($_COOKIE['categoriaInst'] == 2){
    echo("
                  <div class='container'>
                  <div class='row row-cols-8 row-cols-lg-4 g-2 g-lg-3'>
              ");
              foreach($BANNER as $produto_indice => $value){
                  echo("<div class='col'>
                          <div class='card' style='width: 300px;'>
                              <img src=".$value[0]." class='card-img-top' alt=''>
                              <div class='card-body'>
                                  <h5 class='card-title'>".$value[1]."</h5>
                                  <h5 class='card-title'>".$value[2]."</h5>
                                  <a href='#' class='btn btn-primary'>Comprar</a>
                              </div>
                          </div>
                       </div>
                  ");
              }
              echo("</div>
              </div>
              <br>");
              echo("
                    <div class='container'>
                    <div class='row row-cols-8 row-cols-lg-4 g-2 g-lg-3'>
                ");
    
              foreach($THUMB as $produto_indice => $value){
                echo("<div class='col'>
                <div class='card' style='width: 300px;'>
                    <img src=".$value[0]." class='card-img-top' alt=''>
                    <div class='card-body'>
                        <h5 class='card-title'>".$value[1]."</h5>
                        <h5 class='card-title'>".$value[2]."</h5>
                        <a href='#' class='btn btn-primary'>Comprar</a>
                    </div>
                </div>
             </div>
        ");
    }
    echo("</div>
    </div>
    <br>");
    echo("
    <div class='container'>
    <div class='row row-cols-8 row-cols-lg-4 g-2 g-lg-3'>
");
              foreach($FLYER as $produto_indice => $value){
                echo("<div class='col'>
                <div class='card' style='width: 300px;'>
                    <img src=".$value[0]." class='card-img-top' alt=''>
                    <div class='card-body'>
                        <h5 class='card-title'>".$value[1]."</h5>
                        <h5 class='card-title'>".$value[2]."</h5>
                        <a href='#' class='btn btn-primary'>Comprar</a>
                    </div>
                </div>
             </div>
        ");
    }
    echo("</div>
    </div>

    <br>");
    echo("
    <div class='container'>
    <div class='row row-cols-8 row-cols-lg-4 g-2 g-lg-3'>
");
              foreach($FANART as $produto_indice => $value){
                echo("<div class='col'>
                <div class='card' style='width: 300px;'>
                    <img src=".$value[0]." class='card-img-top' alt=''>
                    <div class='card-body'>
                        <h5 class='card-title'>".$value[1]."</h5>
                        <h5 class='card-title'>".$value[2]."</h5>
                        <a href='#' class='btn btn-primary'>Comprar</a>
                    </div>
                </div>
             </div>
        ");
    }
    echo("</div>
    </div>
    <br>");
             
               
 }
 elseif(isset($_COOKIE['categoriaInst']))
 if($_COOKIE['categoriaInst'] == 3){
  echo("
                <div class='container'>
                <div class='row row-cols-8 row-cols-lg-4 g-2 g-lg-3'>
            ");
            foreach($FLYER as $produto_indice => $value){
                echo("<div class='col'>
                        <div class='card' style='width: 300px;'>
                            <img src=".$value[0]." class='card-img-top' alt=''>
                            <div class='card-body'>
                                <h5 class='card-title'>".$value[1]."</h5>
                                <h5 class='card-title'>".$value[2]."</h5>
                                <a href='#' class='btn btn-primary'>Comprar</a>
                            </div>
                        </div>
                     </div>
                ");
            }
            echo("</div>
            </div>
            <br>");

            echo("
                    <div class='container'>
                    <div class='row row-cols-8 row-cols-lg-4 g-2 g-lg-3'>
                ");
            foreach($BANNER as $produto_indice => $value){
              echo("<div class='col'>
              <div class='card' style='width:300px;'>
                  <img src=".$value[0]." class='card-img-top' alt=''>
                  <div class='card-body'>
                      <h5 class='card-title'>".$value[1]."</h5>
                      <h5 class='card-title'>".$value[2]."</h5>
                      <a href='#' class='btn btn-primary'>Comprar</a>
                  </div>
              </div>
           </div>
      ");
  }
  echo("</div>
  </div>

  <br>");
  echo("
  <div class='container'>
  <div class='row row-cols-8 row-cols-lg-4 g-2 g-lg-3'>
");
            foreach($THUMB as $produto_indice => $value){
              echo("<div class='col'>
              <div class='card' style='width: 300px;'>
                  <img src=".$value[0]." class='card-img-top' alt=''>
                  <div class='card-body'>
                      <h5 class='card-title'>".$value[1]."</h5>
                      <h5 class='card-title'>".$value[2]."</h5>
                      <a href='#' class='btn btn-primary'>Comprar</a>
                  </div>
              </div>
           </div>
      ");
  }
  echo("</div>
  </div>
 
  <br>");
  echo("
  <div class='container'>
  <div class='row row-cols-8 row-cols-lg-4 g-2 g-lg-3'>
");
            foreach($FANART as $produto_indice => $value){
              echo("<div class='col'>
              <div class='card' style='width: 300px;'>
                  <img src=".$value[0]." class='card-img-top' alt=''>
                  <div class='card-body'>
                      <h5 class='card-title'>".$value[1]."</h5>
                      <h5 class='card-title'>".$value[2]."</h5>
                      <a href='#' class='btn btn-primary'>Comprar</a>
                  </div>
              </div>
           </div>
      ");
  }
  echo("</div>
  </div>
  <br>");
            
             
}
elseif(isset($_COOKIE['categoriaInst']))
if($_COOKIE['categoriaInst'] == 4){
  echo("
                <div class='container'>
                <div class='row row-cols-8 row-cols-lg-4 g-2 g-lg-3'>
            ");
            foreach($FANART as $produto_indice => $value){
                echo("<div class='col'>
                        <div class='card' style='width:300px;'>
                            <img src=".$value[0]." class='card-img-top' alt=''>
                            <div class='card-body'>
                                <h5 class='card-title'>".$value[1]."</h5>
                                <h5 class='card-title'>".$value[2]."</h5>
                                <a href='#' class='btn btn-primary'>Comprar</a>
                            </div>
                        </div>
                     </div>
                ");
            }
            echo("</div>
            </div>

            <br>");

            echo("
            <div class='container'>
            <div class='row row-cols-8 row-cols-lg-4 g-2 g-lg-3'>
        ");
            foreach($BANNER as $produto_indice => $value){
              echo("<div class='col'>
              <div class='card' style='width: 18rem;'>
                  <img src=".$value[0]." class='card-img-top' alt=''>
                  <div class='card-body'>
                      <h5 class='card-title'>".$value[1]."</h5>
                      <h5 class='card-title'>".$value[2]."</h5>
                      <a href='#' class='btn btn-primary'>Comprar</a>
                  </div>
              </div>
           </div>
      ");
  }
  echo("</div>
  </div>

  <br>");
  echo("
  <div class='container'>
  <div class='row row-cols-8 row-cols-lg-4 g-2 g-lg-3'>
");
            foreach($FLYER as $produto_indice => $value){
              echo("<div class='col'>
              <div class='card' style='width: 18rem;'>
                  <img src=".$value[0]." class='card-img-top' alt=''>
                  <div class='card-body'>
                      <h5 class='card-title'>".$value[1]."</h5>
                      <h5 class='card-title'>".$value[2]."</h5>
                      <a href='#' class='btn btn-primary'>Comprar</a>
                  </div>
              </div>
           </div>
      ");
  }
  echo("</div>
  </div>
  <br>");
  echo("
  <div class='container'>
  <div class='row row-cols-8 row-cols-lg-4 g-2 g-lg-3'>
");
            foreach($THUMB as $produto_indice => $value){
              echo("<div class='col'>
              <div class='card' style='width: 18rem;'>
                  <img src=".$value[0]." class='card-img-top' alt=''>
                  <div class='card-body'>
                      <h5 class='card-title'>".$value[1]."</h5>
                      <h5 class='card-title'>".$value[2]."</h5>
                      <a href='#' class='btn btn-primary'>Comprar</a>
                  </div>
              </div>
           </div>
      ");
  }
  echo("</div>
  </div>
  <br>");
           
             
}

    
  ?>






<!-- Optional JavaScript; choose one of the two! -->

 <!-- Option 1: Bootstrap Bundle with Popper -->
 <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-gtEjrD/SeCtmISkJkNUaaKMoLD0//ElJ19smozuHV6z3Iehds+3Ulb9Bn9Plx0x4" crossorigin="anonymous"></script>

<!-- Option 2: Separate Popper and Bootstrap JS -->
<!--
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js" integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.min.js" integrity="sha384-Atwg2Pkwv9vp0ygtn1JAojH0nYbwNJLPhwyoVbhoPwBhjQPR5VtM2+xf0Uwh9KtT" crossorigin="anonymous"></script>
-->




<!-- Font Awesome -->
<link
 href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css"
 rel="stylesheet"
/>
<!-- Google Fonts -->
<link
 href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700&display=swap"
 rel="stylesheet"
/>
<!-- MDB -->










<?php

include('rodape.php');
?>