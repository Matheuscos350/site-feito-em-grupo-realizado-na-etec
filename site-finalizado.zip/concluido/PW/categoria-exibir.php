<?php include("cabecalho.php"); ?>
<?php include("menu.php"); ?>

	

 <!-- Bootstrap CSS -->
 <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-+0n0xVW2eSR5OomGNYDnhzAbDsOXxcvSN1TPprVMTNDbiYZCxYbOOl7+AMvyTG2x" crossorigin="anonymous">

<link rel="stylesheet" href="css/new 1.css">







<div class="alert alert-dark" role="alert">
<center>Exibir Categorias</center>
</div>
<center>
<section></section>  
<table class="table table-dark table-striped">
  <thead>
    <tr>
      <!-- <th scope="col">idCategoria</th> -->
      <th scope="col">Categoria</th>
      <th scope="col">&nbsp;</th>
	  <th scope="col">&nbsp;</th>
    </tr>
   <tbody>
<?php
    

	include("conexao.php");
	
	$stmt =$pdo ->prepare("SELECT * FROM tbCategoria");
	$stmt ->execute();
	
	while($row = $stmt ->fetch(PDO::FETCH_BOTH)){
		echo("<tr>");
		// echo("<td> $row[0]</td>");
     echo("<td> $row[1]</td>");
     echo "<td>";
		echo "<a href='categoria-excluir.php?id=$row[idCategoria]'> <Img id='logo1' src='img2/li.png'> </a>"; 
	echo "</td>";
	echo "<td>";
      echo "<a href='?idCategoria=$row[0]&categoria=$row[1]'><Img id='logo1' src='img2/al.png'> </a>";
	echo "</td>";
	echo("</tr>");
	
	}
?>
<br>
<br>
</tbody>
</table> 
</center>
</section>
<center>
<div class="card" style="width: 18rem;">
  <img src="img/ney.png" class="card-img-top" alt="...">
  <div class="card-body">
    <i><p class="card-text">"A Esperança é oque nos fortalece"    ~Kratos~</p></i>

<section>
<form method="post" action="categoria-salvar.php" onsubmit="return validarCategoria()" >
	<div>
		<input type="hidden" placeholder="idCategoria" name="txIdCategoria" value="<?php echo @$_GET['idCategoria']; ?>" />
	</div>

	<div>
		<input type="text" placeholder="Categoria" name="txCategoria" id="txCategoria" value="<?php echo @$_GET['categoria']; ?>" />
	</div>

	<div>
		<input type="submit" value="Salvar" onclick="validarCategoria()"/>
	</div>
	</form>

</section>
</div>
</div>
</center>

<?php include("rodape.php"); ?>




	
<script>

function validarCategoria(){
	var categoria = document.getElementById("txCategoria").value; 

	if(categoria.length>3){
		alert("Dados corretos");
		return true;
	}
	else{
		alert("Dados incorretos Insira pelo menos 4 letras no nome da categoria");
		return false;
	}
}
</script>





    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>

    <!-- Option 2: Separate Popper and Bootstrap JS -->
    <!--
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.10.2/dist/umd/popper.min.js" integrity="sha384-7+zCNj/IqJ95wo16oMtfsKbZ9ccEh31eOz1HGyDuCQ6wgnyJNSYdrPa03rtR1zdB" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.min.js" integrity="sha384-QJHtvGhmr9XOIpI6YVutG+2QOK9T+ZnN4kzFN1RtK3zEFEIsxhlmWl5/YESvpZ13" crossorigin="anonymous"></script>
    -->



    