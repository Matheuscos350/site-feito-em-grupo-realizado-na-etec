<?php
    header("Location: index.php");

    $categoria = $_POST['txtCategoria'];

    //criando o cookie
    setcookie('categoriaInst', $categoria); 
?>