<?php
    $nome = $_POST['txtNome'];
    $pr = $_POST['txt1'];
    $qtd = $_POST['txtqtd'];
    $dt = $_POST['txtDt'];
    $tu = $_POST['txtvalor'];
    $po = $_POST['txtvalor2'];


    echo("Olá ".$nome.",O produto selecinado é " .$pr. " e a quantidade é  " .$qtd. " chegara é 15 dias!");

    $res=$tu*$po;




    echo("O valor preço com desconto é ".$res);

?>