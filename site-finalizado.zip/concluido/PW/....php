<?php include("cabecalho.php"); ?>
<?php include("menu.php"); ?>

	

 <!-- Bootstrap CSS -->
 <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-+0n0xVW2eSR5OomGNYDnhzAbDsOXxcvSN1TPprVMTNDbiYZCxYbOOl7+AMvyTG2x" crossorigin="anonymous">

<link rel="stylesheet" href="css/new 1.css">






<div class="alert alert-dark" role="alert">
<center>Exibir Categorias</center>
</div>
<section>
<center>
<table class="table table-dark table-striped">
  <thead>
    <tr>
      <th scope="col">Produto</th>
      <th scope="col">Categoria</th>
      <th scope="col">Valor</th>
      <th scope="col">&nbsp;</th>
    </tr>
   <tbody>
<?php
    

	include("conexao.php");
	
	$stmt =$pdo ->prepare("SELECT idProduto, produto, categoria, valor FROM `tbproduto` p 
  INNER JOIN tbcategoria  c ON p.idCategoria = c.idCategoria");
	$stmt ->execute();
	
	while($row = $stmt ->fetch(PDO::FETCH_BOTH)){
		echo("<tr>");
		echo("<td> $row[produto]</td>");
     echo("<td> $row[categoria]</td>");
		echo("<td> R$ $row[valor]</td>");
    echo "<td>";
			echo "<a href='produto-excluir.php?id=$row[idProduto]'> Excluir </a>"; 
		echo "</td>";
	echo("</tr>");
	
	}
?>
<br>
<br>
</tbody>
</table>

</center>
</section>

<section>

	<form method="post" action="produto-inserir.php">
		<div>
			<input type="text" placeholder="Produto" name="txProduto" />
		</div>

    <?php
      $stmt1 =$pdo ->prepare("SELECT * FROM `tbcategoria` ");
      $stmt1 ->execute();
    ?>
    <div>
      <select name="txIdCategoria" class="form-select" aria-label="Default select example">
        <option value='0' >Selecione uma Categoria</option>
        <?php
          while($row1 = $stmt1 ->fetch(PDO::FETCH_BOTH)){
            echo(" <option value='$row1[0]'>$row1[1] </option>");
          }
        ?>
      </select>
    </div>

		<div>
			<input type="text" placeholder="Valor" name="txValor" />
		</div>

		<div>
			<input type="submit" value="Salvar" />
		</div>
	</form>

</section>
<?php include("rodape.php"); ?>










    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>

    <!-- Option 2: Separate Popper and Bootstrap JS -->
    <!--
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.10.2/dist/umd/popper.min.js" integrity="sha384-7+zCNj/IqJ95wo16oMtfsKbZ9ccEh31eOz1HGyDuCQ6wgnyJNSYdrPa03rtR1zdB" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.min.js" integrity="sha384-QJHtvGhmr9XOIpI6YVutG+2QOK9T+ZnN4kzFN1RtK3zEFEIsxhlmWl5/YESvpZ13" crossorigin="anonymous"></script>
    -->





