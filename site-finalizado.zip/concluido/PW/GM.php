<?php
    $nome = $_POST['txtNome'];
    $pr = $_POST['txt1'];
    $qtd = $_POST['txtqtd'];
    $dt = $_POST['txtDt'];
    $po;
    
// API

    $url = "https://viacep.com.br/ws/$meuCep/json/";
    $json = file_get_contents($url);    
    $data = json_decode($json);
    echo $data->cep . "<br />";
    echo $data->logradouro . "<br />";
    echo $data->bairro . "<br />";
    echo $data->localidade . "<br />";
    echo $data->uf . "<br />";

// FIM 






    //valor compra
    $tu = $_POST['txtvalor'];
    //desconto
    $po = $_POST['porcento'];

    echo("Olá ".$nome." ,O produto selecinado é " . $pr . " e a quantidade é  " . $qtd . " chegara é 15 dias!");

      $vp=$tu-250;
    
    

    echo("<br>O valor preço com desconto é R$".$vp);

?>