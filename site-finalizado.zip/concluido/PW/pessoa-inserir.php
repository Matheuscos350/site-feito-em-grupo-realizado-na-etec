<?php

    $idPessoa = $_POST['txIdPessoa'];
    $nome = $_POST['txNome'];
    $cep = $_POST['txCep'];
    $endereco = $_POST['txEndereco'];
    $numero = $_POST['txNumero'];
    $bairro = $_POST['txBairro'];
    $cidade = $_POST['txCidade'];
    $estado = $_POST['txEstado'];
    //echo " $produto $idCategoria $valor";

    include("conexao.php");

    $stmt = $pdo->prepare("insert into tbpessoa values('$idPessoa','$nome','$cep','$endereco','$numero','$bairro','$cidade','$estado');");	
	$stmt ->execute();


    header("location:loguin.php");

?>