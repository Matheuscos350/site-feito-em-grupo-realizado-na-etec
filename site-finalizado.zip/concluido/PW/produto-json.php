<?php

    include("conexao.php");

    $stmt = $pdo->prepare("select * from tbCategoria");	
    $stmt ->execute();

    while($row = $stmt ->fetch(PDO::FETCH_BOTH)){  
        
        echo"Categorias{ ";
        echo $row[0];
        echo $row[1];
        // echo $row[2];
        // echo $row[3];           					
    }	


?>