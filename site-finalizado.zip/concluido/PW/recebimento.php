<?php
$THUMB= array(
0=> array('./img2/4.jpg','Camisas','R$130.00'),
1=> array('./img2/5.jpg','Camisas','R$200.00'),
2=> array('./img2/6.jpg','Camisas','R$120.00'),
3=> array('./img2/7.jpg','Camisas','R$201.00')
);
$FANART= array(
  0=> array('./img2/16.jpg ','Jaqueta Corta-Vento',' R$ 100,90'),
  1=> array('./img2/17.jpg ','Jaqueta Corta-Vento',' R$ 159,90'),
  2=> array('./img2/18.jpg ','Jaqueta Corta-Vento',' R$ 199,90'),
  3=> array('./img2/20.jpg ','Jaqueta Corta-Vento',' R$ 159,90')
  );
  $BANNER= array(
    0=> array('./img2/8.jpg','CHUTEIRA','R$200.00'),
    1=> array('./img2/9.jpg ','CHUTEIRA','R$120.00'),
    2=> array('./img2/10.jpg ','CHUTEIRA','R$120.00'),
    3=> array('./img2/11.jpg ','CHUTEIRA','R$90.00')
    
    );
    $FLYER= array(
      0=> array('./img2/12.jpg','MEIÃO','R$ 15.00'),
      1=> array('./img2/13.jpg','MEIÃO','R$ 23.00'),
      2=> array('./img2/14.jpg','MEIÃO','R$ 31.00'),
      3=> array('./img2/15.jpg','MEIÃO','R$ 28.00')
    
    );

?>