<?php include("cabecalho.php"); ?>
<?php include("menu.php"); ?>

	

 <!-- Bootstrap CSS -->
 <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-+0n0xVW2eSR5OomGNYDnhzAbDsOXxcvSN1TPprVMTNDbiYZCxYbOOl7+AMvyTG2x" crossorigin="anonymous">
<!-- CSS only -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">


<link rel="stylesheet" href="css/new 1.css">






<div class="alert alert-dark" role="alert">
<center>Exibir Produto</center>
</div>
<section>
<center>
<table class="table table-dark table-striped">
  <thead>
    <tr>
      <th scope="col">Produto</th>
      <th scope="col">Categoria</th>
      <th scope="col">Valor</th>
      <th scope="col">&nbsp;</th>
      <th scope="col">&nbsp;</th>
    </tr>
   <tbody>
	   
<?php
    

	include("conexao.php");
	
	$stmt =$pdo ->prepare("SELECT idProduto, produto, categoria, valor FROM `tbproduto` p 
  INNER JOIN tbcategoria  c ON p.idCategoria = c.idCategoria");
	$stmt ->execute();
	
	while($row = $stmt ->fetch(PDO::FETCH_BOTH)){
		echo("<tr>");
		echo("<td> $row[produto]</td>");
    	 echo("<td> $row[categoria]</td>");
		echo("<td> R$ $row[valor]</td>");
   		 echo "<td>";
		

			// echo "<button type='button' class='btn btn-primary' data-bs-toggle='modal' data-bs-target='#exampleModal'> Excluir </button>"; 

			

	 echo "<i class='bi bi-trash'><a href='produto-excluir.php?id=$row[idProduto]'> <Img id='logo1' src='img2/li.png'></a></i>"; 


		echo "</td>";
    echo "<td>";
      echo "<a href='?idProduto=$row[0]&produto=$row[1]&categoria=$row[2]&valor=$row[3]'> <Img id='logo1' src='img2/al.png'> </a>";
		echo "</td>";
	echo("</tr>");
	
	}
?>
<br>
<br>
</tbody>
</table>

</center>
</section>


<center>
<div class="card" style="width: 18rem;">
  <img src="img/ney.png" class="card-img-top" alt="...">
  <div class="card-body">
    <!-- <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p> -->


<section>

<form method="post" action="produto-salvar.php" onsubmit="return validarTudo()">
    <div>
			<input type="hidden" placeholder="idProduto" name="txIdProduto" value="<?php echo @$_GET['idProduto']; ?>" />
		</div>

		<div>
			<input type="text" placeholder="Produto" name="txProduto" id="txProduto" value="<?php echo @$_GET['produto']; ?>" />
		</div>

    <?php
			$stmtCat = $pdo->prepare("select * from tbCategoria");	
			$stmtCat ->execute();				
		?>
    <div>

      <?php 
				$cat = @$_GET['categoria'];				
			?>
      
      <select name="txIdCategoria">
				<option value='0'> Escolha uma categoria </option>
				<?php 
					while($rowCat = $stmtCat ->fetch(PDO::FETCH_BOTH)){							
						if($cat==$rowCat[1]){
							$sel = "selected";	
						}
						else{
							$sel = "";	
						}
						echo "<option value='$rowCat[0]' $sel> $rowCat[1] </option>";					
					}
				?>				
			</select>
    </div>
    
    <div>
			<input type="text" placeholder="Valor" name="txValor" id="txValor" value="<?php echo @$_GET['valor']; ?>" />
		</div>

		<div>
			<input type="submit" value="Salvar" />
		</div>
	</form>

</section>

<!-- <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Tem Certeza?</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        Você Deseja Excluir o Produto?
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Fechar</button>
        
      </div>
    </div>
  </div>
</div> -->


</div>
</div> 

</center>
<?php include("rodape.php"); ?>

<script>

    function validarProduto(){
        var produto = document.getElementById("txProduto").value; 

        if(produto.length>3){
			alert("Dados corretos");
            return true;
        }
        else{
			alert("Dados incorretos Insira pelo menos 4 letras no nome do produto");
            return false;
        }
    }

    function validarValor(){
        var valor = document.getElementById("txValor").value; 

        if(parseFloat(valor) <= 0){
			alert("Dados corretos Insira um valor maior que 0");
			return false;
        }
        else{
			// alert("Dados corretos");
            return true;
        }

    }

    function validarTudo(){
        if(validarProduto() && validarValor()){
            // alert("Dados corretos");    
            return true;
        }
        else{
            alert("Dados incorretos");
            return false;
        }
    }

</script>







    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>

    <!-- Option 2: Separate Popper and Bootstrap JS -->
    <!--
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.10.2/dist/umd/popper.min.js" integrity="sha384-7+zCNj/IqJ95wo16oMtfsKbZ9ccEh31eOz1HGyDuCQ6wgnyJNSYdrPa03rtR1zdB" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.min.js" integrity="sha384-QJHtvGhmr9XOIpI6YVutG+2QOK9T+ZnN4kzFN1RtK3zEFEIsxhlmWl5/YESvpZ13" crossorigin="anonymous"></script>
    -->





