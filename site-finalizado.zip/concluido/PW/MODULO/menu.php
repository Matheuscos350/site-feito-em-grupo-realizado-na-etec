<nav>
  <ul>
    <li>

<a href="#"> OPÇÃO 1 </a>
     
    </li>
      <li>

<a href="#"> OPÇÃO 2 </a>

    </li>
      </ul>
        </nav>